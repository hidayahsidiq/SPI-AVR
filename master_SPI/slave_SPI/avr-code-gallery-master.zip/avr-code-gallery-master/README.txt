AVR Code Gallery - maxEmbedded
==============================

This repository is basically the AVR Code Gallery of maxEmbedded. You can find all the codes for all the AVR related posts here at one place. So no more searching around the website for code!

DISCLAIMER

This is the same code as given in the above URL. Though the code is tested and approved, the author is not responsible for any damage, physical, mental or social, which might occur due to the implementation	of this code and its derivatives, whether in full or part thereof. Use it at your own risk.

Links:
maxEmbedded Homepage: http://maxEmbedded.com/
maxEmbedded Code Gallery Page: http://maxEmbedded.com/code-gallery/
maxEmbedded Contact Page: http://maxEmbedded.com/contact/

maxEmbedded is maintained and run by
Mayank Prasad
Arizona State University
max@maxEmbedded.com
